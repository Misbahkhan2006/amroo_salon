<?php
session_start();
if (empty($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

require_once __DIR__ . '/db.php';
header('Content-Type: application/json');

$id = intval($_POST['id'] ?? 0);

if ($id > 0) {
    $query = "DELETE FROM appointments WHERE id = $id";
    if (mysqli_query($con, $query)) {
        echo json_encode(['success' => true, 'message' => 'Appointment deleted']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid ID']);
}
?>
