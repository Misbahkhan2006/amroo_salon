<?php
require_once('db.php');
header('Content-Type: application/json');
session_start();

$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

$result = mysqli_query($con, "SELECT * FROM customers WHERE email='$email' AND password='$password'");
if (mysqli_num_rows($result) == 1) {
  $_SESSION['customer_email'] = $email;
  echo json_encode(['success' => true, 'message' => 'Login successful!']);
} else {
  echo json_encode(['success' => false, 'error' => 'Invalid email or password.']);
}
