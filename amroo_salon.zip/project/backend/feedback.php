<?php
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');
$rating = intval($_POST['rating'] ?? 0);

if ($name === '' || $email === '' || $message === '' || $rating === 0) {
    echo json_encode(['success' => false, 'error' => 'All fields are required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'Invalid email format']);
    exit;
}

// Insert into DB
try {
    $stmt = $con->prepare("INSERT INTO feedback (name, email, message, rating, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssi", $name, $email, $message, $rating);
    $stmt->execute();
    echo json_encode(['success' => true]);
    $stmt->close();
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'error' => 'Server error: '.$e->getMessage()]);
}
?>
