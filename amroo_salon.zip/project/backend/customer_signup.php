<?php
require_once('db.php');
header('Content-Type: application/json');

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($name == '' || $email == '' || $password == '') {
  echo json_encode(['success' => false, 'error' => 'All fields are required.']);
  exit;
}

$check = mysqli_query($con, "SELECT * FROM customers WHERE email='$email'");
if (mysqli_num_rows($check) > 0) {
  echo json_encode(['success' => false, 'error' => 'Email already registered.']);
  exit;
}

mysqli_query($con, "INSERT INTO customers (name, email, password) VALUES ('$name','$email','$password')");
echo json_encode(['success' => true, 'message' => 'Account created successfully!']);
