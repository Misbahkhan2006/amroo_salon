<?php
require_once('db.php');
header('Content-Type: application/json');

$email = trim($_POST['email'] ?? '');
$result = mysqli_query($con, "SELECT * FROM customers WHERE email='$email'");

if (mysqli_num_rows($result) == 1) {
  echo json_encode(['success' => true, 'message' => 'Reset link sent to your email (demo).']);
} else {
  echo json_encode(['success' => false, 'error' => 'Email not found.']);
}
