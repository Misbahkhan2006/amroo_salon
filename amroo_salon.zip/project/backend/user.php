<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$name     = trim($_POST['name'] ?? '');
$email    = trim($_POST['email'] ?? '');
$mobile   = trim($_POST['mobile'] ?? '');
$service  = trim($_POST['appointment_for'] ?? '');
$date     = trim($_POST['date'] ?? '');
$time     = trim($_POST['time'] ?? '');
$message  = trim($_POST['message'] ?? '');

$errors = [];
if ($name === '') $errors[] = 'Name is required';
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
if ($mobile === '' || !preg_match('/^[0-9]{10,15}$/', $mobile)) $errors[] = 'Valid mobile number required';
if ($service === '') $errors[] = 'Please select a service';
if ($date === '') $errors[] = 'Please select a date';
if ($time === '') $errors[] = 'Please select a time';

if (!empty($errors)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

try {
    $sql = "INSERT INTO appointments (name, email, phone, service, appointment_date, appointment_time, message)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'sssssss', $name, $email, $mobile, $service, $date, $time, $message);
    mysqli_stmt_execute($stmt);
    $id = mysqli_insert_id($con);
    mysqli_stmt_close($stmt);

    echo json_encode(['success' => true, 'id' => $id, 'message' => 'Appointment booked successfully!']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error']);
}
?>
