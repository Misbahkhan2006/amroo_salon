<?php
$con = mysqli_connect("localhost", "root", "", "amro_salon");

if (!$con) {
    die(json_encode(["success" => false, "error" => "Database connection failed."]));
}
?>
