<?php
session_start();
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    echo json_encode(['success' => false, 'error' => 'All fields are required']);
    exit;
}

// For now, hardcoded admin credentials (you can store in DB later)
$admin_user = 'admin';
$admin_pass = '1234'; // change this

if ($username === $admin_user && $password === $admin_pass) {
    $_SESSION['admin_logged_in'] = true;
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
}
?>
