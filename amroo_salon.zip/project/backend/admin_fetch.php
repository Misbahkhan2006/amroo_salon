<?php
session_start();
if (empty($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

require_once __DIR__ . '/db.php';
header('Content-Type: application/json');

$result = mysqli_query($con, "SELECT * FROM appointments ORDER BY id DESC");
$appointments = [];

while ($row = mysqli_fetch_assoc($result)) {
    $appointments[] = $row;
}

echo json_encode(['success' => true, 'data' => $appointments]);
?>
